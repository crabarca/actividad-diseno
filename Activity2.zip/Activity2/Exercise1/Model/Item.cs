namespace Activity2
{
    public class Item
    {
        public int Id { get; }
        public int Price { get; }

        public Item(int id, int price)
        {
            Id = id;
            Price = price;
        }
    }
}