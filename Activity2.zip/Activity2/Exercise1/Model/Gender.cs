namespace Activity2
{
    public enum Gender
    {
        Male, Female
    }
}