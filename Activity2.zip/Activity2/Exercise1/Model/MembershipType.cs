namespace Activity2
{
    public enum MembershipType
    {
        Platinum, Gold, Silver, None
    }
}