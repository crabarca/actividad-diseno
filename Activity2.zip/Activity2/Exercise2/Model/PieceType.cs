namespace Exercise2
{
    public enum PieceType
    {
        Pawn, Bishop, Knight, Tower, Queen, King
    }
}